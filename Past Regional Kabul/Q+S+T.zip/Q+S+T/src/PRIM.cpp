// A school method based C++ program to
// check if a number is prime
#include <bits/stdc++.h>
#include <string>
using namespace std;

// function check whether a number
// is prime or not
bool isPrime(int n)
{
	// Corner case
	if (n <= 1)
		return false;

	// Check from 2 to n-1
	for (int i = 2; i < n; i++)
		if (n % i == 0)
			return false;

	return true;
}

// Driver Program
int main()
{
    int n;

   scanf("%d",&n);
   int in[n][5];
   int out[n];
    for (int i=0; i < n; i++)
    {
        int a, b, c, d, e;

        scanf("%d%d%d%d%d",&a, &b, &c, &d, &e);
        in[i][0]=a;
        in[i][1]=b;
        in[i][2]=c;
        in[i][3]=d;
        in[i][4]=e;
    }
/*        for (int z=0; z < 5; z++){
        cout << in[z] << "\n";
    }
*/
for (int m=0; m < n; m++)
    {
        for(int j=0; j < 5; j++){
        bool prime = false;
        while (!prime)
        {
            if (isPrime(in[m][j])) {prime = true; }
        else {in[m][j]= in[m][j]+1; }
        }
        }
        out[m]=0;
        for(int k =0; k < 5; k++){
            out[m] = out[m]+in[m][k];
            //cout << out[m] << "   out[m]" << "\n";
        }
    }
    for (int z=0; z < n; z++){
        printf("%d\n",out[z]);
    }
	//isPrime(111) ? cout << " true\n" :
		//		cout << " false\n";
	return 0;
}
