import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Bank {

	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);

		// teller => <timeframe => processed-count>
		Map<String, Map<String, Integer>> tellerCounts = new HashMap<>();
		// teller => <customer => enqueue time>
		Map<String, Map<String, String>> customerRecords = new HashMap<>();

		while (input.hasNextLine()) {
			String inputRecord = input.nextLine();

			// end of the input
			if (inputRecord.toLowerCase().equals("endofinput"))
				break;

			// split to teller,customer, and time
			String[] inputRecordParts = inputRecord.split(" ");
			String teller = inputRecordParts[0];
			String customer = inputRecordParts[1];
			String time = null;
			if (inputRecordParts.length == 3)
				time = inputRecordParts[2];

			// is there a record for teller?
			Map<String, String> customerRecord = customerRecords.get(teller);
			if (customerRecord == null) {
				customerRecords.put(teller, customerRecord = new HashMap<>());
			}

			// if customer left the queue
			if (time == null) {
				// remove it from record
				customerRecord.remove(customer);
			} else {
				// if customer joined the queue
				if (customerRecord.get(customer) == null) {
					// add it to record
					customerRecord.put(customer, time);
				} 
				// if customer was processed
				else { 
					// remove the customer from record
					customerRecord.remove(customer);

					// find the processed timeframe
					String timeframe = time.substring(0, time.indexOf(":")) + time.substring(time.lastIndexOf(":") + 3);

					// update teller timeframe processed count
					Map<String, Integer> tellerCount = tellerCounts.get(teller);
					if (tellerCount == null) {
						tellerCounts.put(teller, tellerCount = new HashMap<>());
					}
					tellerCount.put(timeframe, tellerCount.getOrDefault(timeframe, 0) + 1);
				}
			}
		}

		// flatten the records
		// teller, count, timeframe
		List<Object[]> flatTellerCounts = new ArrayList<>();

		// for every teller
		for (String teller : tellerCounts.keySet()) {
			// get the timeframe counts
			Map<String, Integer> tellerCount = tellerCounts.get(teller);

			int procCount = 0, countAtPeak = 0;
			String peakTimeframe = null;

			// for each timeframe
			for (String timeframe : tellerCount.keySet()) {
				// find the peak timeframe
				int tfcount = tellerCount.get(timeframe);

				procCount += tfcount;

				// more processed count or the smaller time frame
				if (tfcount > countAtPeak || (tfcount == countAtPeak && timeframe.compareTo(peakTimeframe) < 0)) {
					countAtPeak = tfcount;
					peakTimeframe = timeframe;
				}
			}

			// flatted
			flatTellerCounts.add(new Object[] { teller, procCount, peakTimeframe });
		}

		// sort the flatted list 
		flatTellerCounts.sort((f1, f2) -> {
			String f1Teller = (String) f1[0];
			int f1Count = (Integer) f1[1];

			String f2Teller = (String) f2[0];
			int f2Count = (Integer) f2[1];

			// top processed first
			if (f1Count != f2Count)
				return f2Count - f1Count;

			// or sort based on teller name in ascending order
			return f1Teller.compareTo(f2Teller);
		});

		// print the output
		for (Object[] flatTellerCount : flatTellerCounts) {
			String flatTeller = flatTellerCount[0] + " " + flatTellerCount[1] + " " + flatTellerCount[2];
			System.out.println(flatTeller);
		}

		input.close();
	}
}
