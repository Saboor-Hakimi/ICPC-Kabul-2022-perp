
import java.util.Arrays;
import java.util.Scanner;

public class KabulTransportation {
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		int testCase = Integer.parseInt(input.nextLine()); 
		if (testCase == 0) {
			System.out.println(testCase);
		}
		else {
			while (testCase > 0) {
			int R = Integer.parseInt(input.nextLine());
			int minTime = 720;
			while (R > 0) {
				
					String route = input.nextLine();
					String[] arrRoute = route.split(" ");
					int len = arrRoute.length;
					int routeTime = 0;
					if (len >= 2) {
						for (int i = 2; i< len-1 ; i+= 4) {
							routeTime = Integer.parseInt(arrRoute[i]) + routeTime;
						}
					}
					if (routeTime <= minTime)
					{
						minTime = routeTime;
					}
					R -= 1;
					
				}
				
				System.out.println(minTime);
				testCase--;
			}
		}
		
	}

}