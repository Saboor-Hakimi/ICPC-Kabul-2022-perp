#include <stdio.h>

char *k = "QWERTYUIOPASDFGHJKLZXCVBNM";

main(){
   int i,c;
   while (EOF != (c = getchar())) {
      for (i=0;k[i] && k[i]!=c;i++);
      if (k[i]) putchar(k[i+1]); else putchar(c);
   }
}
