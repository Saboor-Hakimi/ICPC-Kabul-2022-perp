import java.util.Arrays;
import java.util.Scanner;

/**
 * Print the given input justified according to given max number of character
 * per line.
 * 
 * @author jone30rw
 */
public class JustifyLine {

	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);

		int lLength = Integer.parseInt(input.nextLine());

		while (input.hasNextLine()) {
			String paragraph = input.nextLine();

			// end of the input
			if (paragraph.toLowerCase().equals("endofinput"))
				break;

			// remove any heading or trailing spaces
			paragraph = paragraph.trim();

			// do not ignore the empty lines
			if (paragraph.length() == 0) {
				System.out.println(paragraph);
			} else {
				// split the paragraph into words
				String[] words = paragraph.split(" ");
				// wlength => current virtual line length
				// start => start index for words array
				int wlength = 0, start = 0;

				// iterate through words
				for (int last = 0; last < words.length; last++) {
					// select words that can be fit in current virtual line
					if (wlength + (1 + words[last].length()) <= lLength) {
						// only add spaces before word after first word
						if (wlength > 0)
							words[last] = " " + words[last];

						// calculate the added words length to not exceed the char per line
						wlength += words[last].length();
					} else
					// if the word is big enough that fit the whole the line
					if (words[last].length() == lLength) {
						// just print it
						System.out.println(words[last]);
					}
					// we have selected enough words, now lets justify them
					else {
						// justify the selected words
						// from start index to last index
						String justified = justify(words, start, last, wlength, lLength);

						System.out.println(justified);

						// reset the selected virtual line length to 0
						// and change the start and last index
						wlength = 0;
						start = last;
						last -= 1;
					}
				}

				// if there is some words left that is not justified
				if (wlength > 0) {
					// then justify them too
					String justified = justify(words, start, words.length, wlength, lLength);

					System.out.println(justified);
				}
			}
		}

		input.close();
	}

	private static String justify(String[] words, int start, int last, int wlength, int lLength) {
		// only if the line is long enough to be justified
		if (wlength >= lLength / 2) {
			// if there is only one word, then we can not justify it
			if (last - start == 1)
				return words[start];

			// how many more space do we need?
			int sneeded = lLength - wlength;

			// until no more extra space is needed
			// ignore the first word, because spaces are added before word.
			// so we do not need our first word to have spaces before it.
			// however it would also waste the spaces and our final result will be
			// incorrect.
			for (int idx = start + 1; sneeded > 0; idx++, sneeded--) {
				// don't add spaces to end of last word
				if (idx == last)
					// go start from first one again
					idx = start + 1;

				// add an extra space before the word
				words[idx] = " " + words[idx];
			}
		}

		// join the virtual line and return it
		return String.join("", Arrays.copyOfRange(words, start, last)).trim();
	}
}
