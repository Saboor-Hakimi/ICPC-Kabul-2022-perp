import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

/**
 * 2048 Game Logic
 * 
 * @author jone30rw
 */
public class Q2049 {

	// scores, nextmoves, and the board array
	private int score;
	private String[] nextMoves;
	private int[][] board;

	/**
	 * Set the current score
	 * 
	 * @param score
	 */
	public void setScore(Integer score) {
		this.score = score;
	}

	/**
	 * Return current score
	 * 
	 * @return score
	 */
	public Integer getScore() {
		return score;
	}

	/**
	 * parse next moves from the given string
	 * 
	 * @param nextMoveString
	 */
	public void parseNextMoves(String nextMoveString) {
		// every move is 4 char long
		// move,next random number,row,column
		// L212
		// move left, a new 2 will appear at row 1, column 2
		nextMoves = new String[nextMoveString.length() / 4];

		// extract the moves and store them in the nextMoves array
		for (int i = 0, j = 0; i < nextMoveString.length(); i += 4, j++) {
			nextMoves[j] = nextMoveString.substring(i, i + 4);
		}
	}

	/**
	 * parse board content from given string
	 * 
	 * @param boardString
	 */
	public void parseBoard(String boardString) {
		// board is 4 by 4
		board = new int[4][4];

		// board content are separated by space
		String[] boardValues = boardString.split(" ");
		int boardValuesIdx = 0;

		// extract the each cell content and set it to board array
		for (int boardRow = 0; boardRow < board.length; boardRow++) {
			for (int boardColumn = 0; boardColumn < board[boardRow].length; boardColumn++) {
				board[boardRow][boardColumn] = Integer.parseInt(boardValues[boardValuesIdx++]);
			}
		}
	}

	/**
	 * iterate through next moves and do them
	 */
	public void doNextMoves() {
		for (String nextMove : nextMoves) {
			// move(direction, new2or4 appearing)
			move(nextMove.substring(0, 1), nextMove.substring(1));
		}
	}

	/**
	 * perform the given move
	 * 
	 * @param direction
	 * @param new2or4
	 */
	private void move(String direction, String new2or4) {
		// based on direction
		switch (direction) {
		case "U": // if up
			// for every column
			// move things from down to up
			// ---------------------------
			// start from row 0, column 0 to 3
			move_hlpr(0, 0, 1, 0);
			move_hlpr(0, 1, 1, 0);
			move_hlpr(0, 2, 1, 0);
			move_hlpr(0, 3, 1, 0);
			break;
		case "D": // if down
			// same as up, but with different direction
			move_hlpr(3, 0, -1, 0);
			move_hlpr(3, 1, -1, 0);
			move_hlpr(3, 2, -1, 0);
			move_hlpr(3, 3, -1, 0);
			break;
		case "R": // if right
			// same as up, but with different direction
			move_hlpr(0, 3, 0, -1);
			move_hlpr(1, 3, 0, -1);
			move_hlpr(2, 3, 0, -1);
			move_hlpr(3, 3, 0, -1);
			break;
		case "L": // if left
			// same as up, but with different direction
			move_hlpr(0, 0, 0, 1);
			move_hlpr(1, 0, 0, 1);
			move_hlpr(2, 0, 0, 1);
			move_hlpr(3, 0, 0, 1);
			break;
		default:
			// otherwise return
			return;
		}

		// set the new random appearing 2 or 4
		int val = Integer.parseInt(new2or4.substring(0, 1));
		int row = Integer.parseInt(new2or4.substring(1, 2));
		int col = Integer.parseInt(new2or4.substring(2, 3));
		board[row][col] = val;
	}

	/**
	 * do the actual move
	 * 
	 * @param startAtRow      start from this row
	 * @param startAtColumn   start from this column
	 * @param rowIncrement    in every iteration change row by this value
	 * @param columnIncrement in every iteration change column by this value
	 */
	private void move_hlpr(int startAtRow, int startAtColumn, int rowIncrement, int columnIncrement) {
		/*
		 * ############################## 
		 * if rowIncrement is 0: it moves left or right
		 * else if rowIncrement is 1: it moves up 
		 * else if rowIncrement is -1: it moves down
		 * 
		 * ############################## 
		 * if columnIncrement is 0: it moves up or down
		 * else if columnIncrement is 1: it moves left 
		 * else if columnIncrement is -1: it moves right
		 */
		// join cells
		rowIteration: for (
				// start from startAtRow
				int rowCounter = 0, joiningRow = startAtRow;
				// only iterate 4 times
				rowCounter <= 3 && joiningRow >= 0 && joiningRow <= 3;
				// increment by rowIncrement
				rowCounter++, joiningRow += rowIncrement) {
			columnIteration: for (
					// start from startAtColumn
					int columnCounter = 0, joiningColumn = startAtColumn;
					// only iterate 4 times
					columnCounter <= 3 && joiningColumn >= 0 && joiningColumn <= 3;
					// increment by columnIncrement
					columnCounter++, joiningColumn += columnIncrement) {
				/**
				 * joiningRow x joiningColumn is the cell that we want to find other similar
				 * cell to join
				 */

				// skip the cell that if it is 0
				if (board[joiningRow][joiningColumn] == 0) {
					// continue the corresponding loop
					if (rowIncrement != 0)
						continue rowIteration;
					if (columnIncrement != 0)
						continue columnIteration;
				}

				for (
						// start from nextRow, nextColumn
						// (depending on rowIncrement, and columnIncrement)
						int joinWithRow = joiningRow + rowIncrement, joinWithColumn = joiningColumn + columnIncrement;
						// make sure we are in bound (0-3)
						joinWithRow >= 0 && joinWithRow <= 3 && joinWithColumn >= 0 && joinWithColumn <= 3;
						// increment by rowIncrement, and columnIncrement
						joinWithRow += rowIncrement, joinWithColumn += columnIncrement) {
					/*
					 * joinWithRow x joinWithColumn is the cell that we are checking to merge with
					 * joiningRow x joiningColumn
					 */
					// skip the cell if it is 0
					if (board[joinWithRow][joinWithColumn] == 0) {
						continue;
					} else
					// if the cells have same value
					if (board[joiningRow][joiningColumn] == board[joinWithRow][joinWithColumn]) {
						// merge the cells
						board[joiningRow][joiningColumn] *= 2;
						// clear the merged cell
						board[joinWithRow][joinWithColumn] = 0;

						// increase the score
						score += board[joiningRow][joiningColumn];

						// start next iterations from joinWithRow x joinWithColumn
						joiningRow = joinWithRow;
						joiningColumn = joinWithColumn;
					}
					// or there is a cell with another value (other than joiningRow x joiningColumn)
					// eg: 1.[2] 2.[4] 3.[2] 4.[2]
					// here we can not merge those two 2 (1, 3), because there is a 4 (2) in between
					// so start from next cell (4)
					else {
						joiningRow = joinWithRow - rowIncrement;
						joiningColumn = joinWithColumn - columnIncrement;
					}

					// continue the corresponding loop
					if (rowIncrement != 0)
						continue rowIteration;
					if (columnIncrement != 0)
						continue columnIteration;
				}
			}

			/*
			 * if going left or right break row counter (because in this case row counter
			 * doesn't increment) if we iterated all columns
			 */
			if (columnIncrement != 0)
				break;
		}

		// collapse cells
		rowIteration: for (
				// start from startAtRow
				int rowCounter = 0, collapsingRow = startAtRow;
				// only iterate 4 times
				rowCounter <= 3 && collapsingRow >= 0 && collapsingRow <= 3;
				// increment by rowIncrement
				rowCounter++, collapsingRow += rowIncrement) {
			columnIteration: for (
					// start from startAtColumn
					int columnCounter = 0, collapsingColumn = startAtColumn;
					// only iterate 4 times
					columnCounter <= 3 && collapsingColumn >= 0 && collapsingColumn <= 3;
					// increment by columnIncrement
					columnCounter++, collapsingColumn += columnIncrement) {
				/**
				 * collapsingRow x collapsingColumn is the cell that we want to find other cell
				 * to collapse to this cell
				 */

				// skip cell if it is not empty
				if (board[collapsingRow][collapsingColumn] != 0) {
					// continue the corresponding loop
					if (rowIncrement != 0)
						continue rowIteration;
					if (columnIncrement != 0)
						continue columnIteration;
				}

				for (
						// start from nextRow, nextColumn
						// (depending on rowIncrement, and columnIncrement)
						int collapsedRow = collapsingRow + rowIncrement, //
						collapsedColumn = collapsingColumn + columnIncrement;
						// make sure we are in bound (0-3)
						collapsedRow >= 0 && collapsedRow <= 3 && collapsedColumn >= 0 && collapsedColumn <= 3;
						// increment by rowIncrement, and columnIncrement
						collapsedRow += rowIncrement, collapsedColumn += columnIncrement) {
					/*
					 * collapsedRow x collapsedColumn is the cell that we are going to collapse at
					 * collapsingRow x collapsingColumn
					 */
					// if the cell has a value
					if (board[collapsedRow][collapsedColumn] != 0) {
						// collapse it
						board[collapsingRow][collapsingColumn] = board[collapsedRow][collapsedColumn];
						board[collapsedRow][collapsedColumn] = 0;

						// continue the corresponding loop
						if (rowIncrement != 0)
							continue rowIteration;
						if (columnIncrement != 0)
							continue columnIteration;
					}
				}
			}

			/*
			 * if going left or right break row counter (because in this case row counter
			 * doesn't increment) if we iterated all columns
			 */
			if (columnIncrement != 0)
				break;
		}
	}

	/**
	 * print the board
	 */
	public void printBoard() {
		// for each row
		for (int[] row : board) {
			// print the columns
			for (int column : row) {
				System.out.printf("%2d  ", column);
			}

			System.out.println();
		}
	}

	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		Scanner input = new Scanner(System.in);

		Q2049 q2048 = new Q2049();

		String score = input.nextLine();
		q2048.setScore(Integer.parseInt(score));

		String nextMoves = input.nextLine();
		q2048.parseNextMoves(nextMoves);

		String board = input.nextLine();
		q2048.parseBoard(board);
		q2048.doNextMoves();

		int finalScore = q2048.getScore();
		System.out.println(finalScore);
		
		input.close();
	}
}
