import static java.lang.Integer.parseInt;
import static java.lang.Math.max;
import static java.lang.System.out;
import static java.util.Arrays.asList;
import static java.util.Arrays.copyOfRange;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ProjMang {
	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				Map<String, List<String>> taskDeps = new HashMap<>();
				Map<String, Integer> taskDurations = new HashMap<>();

				String line = "";
				while (!(line = input.nextLine()).isEmpty()) {
					String[] parts = line.split(" ");

					String taskName = parts[0];
					taskDurations.put(taskName, parseInt(parts[1]));

					List<String> deps = new ArrayList<>();
					deps.addAll(asList(copyOfRange(parts, 2, parts.length)));
					taskDeps.put(taskName, deps);
				}

				int longest = 0;
				for (String taskName : taskDurations.keySet()) {
					// find the longest duration for each task
					longest = max(longest, calcDuration(taskName, taskDeps, taskDurations, new ArrayList<String>()));
				}

				out.println(longest);
			}
		}
	}

	// traverse all task-deps to find the longest task-order
	private static int calcDuration(String taskName, //
			Map<String, List<String>> taskDeps, Map<String, Integer> taskDurations, List<String> visited) {
		visited.add(taskName);
		int duration = taskDurations.get(taskName);
		int longest = duration;

		for (String dep : taskDeps.getOrDefault(taskName, new ArrayList<>())) {
			if (visited.contains(dep)) {
				continue;
			}

			longest = max(longest, duration + calcDuration(dep, taskDeps, taskDurations, visited));
		}

		visited.remove(taskName);
		return longest;
	}
}
