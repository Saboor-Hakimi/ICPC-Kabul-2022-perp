import static java.lang.Integer.parseInt;
import static java.lang.System.out;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NIdOrder {
	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			List<String> lines = new ArrayList<>();
			while (input.hasNextLine()) {
				String line = input.nextLine();
				if (line.isEmpty()) {
					break;
				}
				lines.add(line);
			}

			while (tsCount-- > 0) {
				List<Integer> stepMins = new ArrayList<>();

				while (lines.get(0).contains("=")) {
					stepMins.add(parseInt(lines.remove(0).split("=")[1]));
				}

				int[] dtime = { 1, 8, 0 }; // 1 8:0
				while (!lines.isEmpty() && isNumber(lines.get(0))) {
					// print the visiting time for current family
					out.println(dtime[0] + " " + dtime[1] + ":" + dtime[2]);

					int count = parseInt(lines.remove(0));
					while (count-- > 0) { // for each member
						for (int stepMin : stepMins) { // repeat all steps
							next(dtime, stepMin); // ensure the rules
						}
					}
				}
			}
		}
	}

	private static void next(int[] dtime, int stepMin) {
		// can be done today?
		if ((dtime[1] - 8) * 60 + dtime[2] + stepMin > 479) {
			// yes, then start from 8:0
			dtime[0]++;
			dtime[1] = 8;
			dtime[2] = 0;
		} else {
			// no, then find the next time
			dtime[2] += stepMin;
			if (dtime[2] >= 60) {
				dtime[1] += dtime[2] / 60;
				dtime[2] %= 60;
			}
		}
	}

	private static boolean isNumber(String string) {
		try {
			parseInt(string);
			return true;
		} catch (Exception exp) {
			return false;
		}
	}
}
