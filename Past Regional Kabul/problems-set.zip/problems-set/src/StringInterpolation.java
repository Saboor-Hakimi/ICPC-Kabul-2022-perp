import static java.lang.Integer.parseInt;
import static java.lang.System.out;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class StringInterpolation {

	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				Map<String, String> params = new HashMap<>();

				String line = "";
				while (!(line = input.nextLine()).equals("---")) {
					String[] param = line.split("=", 2);
					params.put(param[0], param[1]);
				}

				StringBuilder content = new StringBuilder();
				while (!(line = input.nextLine()).equals("---")) {
					content.append(line);
				}

				int start = -1;
				// interpolate string
				// lastIndexOf is used to start from deepest param
				while ((start = content.lastIndexOf("${")) > -1) {
					// it is guaranteed of no partial ${param} format
					int end = content.indexOf("}", start) + 1;

					// find and replace the param
					String param = content.substring(start + 2, end - 1);
					content.replace(start, end, params.getOrDefault(param, param));
				}

				out.println(content.toString());
			}
		}
	}
}
