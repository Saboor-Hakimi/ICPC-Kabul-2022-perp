import java.util.Scanner;

public class ToMars {

	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);

		int testCase = Integer.parseInt(inp.nextLine());
		String selectingCars = "";
		double time = 0.0;

		for (int i = 0; i < testCase; i++) {
			int station = Integer.parseInt(inp.nextLine());

			for (int st = 0; st < station; st++) {

				int nextStationDistance = Integer.parseInt(inp.nextLine());
				String line = inp.nextLine();
				String cars[] = line.split(",");
				int speed1 = 0;
				String car1 = "";
				double time1 = 0.0;

				for (int j = 0; j < cars.length; j++) {
					String splitResult[] = cars[j].split("-");
					int speed = Integer.parseInt(splitResult[0]);
					int liter = Integer.parseInt(splitResult[1]);
					int petrolSpent = Integer.parseInt(splitResult[2]);
					int carDistance = liter / petrolSpent;

					if (carDistance >= nextStationDistance) {

						if (speed1 < speed) {
							speed1 = speed;
							car1 = j + 1 + "";
							double nextS = nextStationDistance;
							double sp = speed;
							time1 = (nextS / sp);
						}
					}
				}
				selectingCars += car1 + " ";
				time += time1;
			}
			System.out.format("%.3f", time);
			System.out.println();
			System.out.println(selectingCars);
		}

		inp.close();
	}
}
