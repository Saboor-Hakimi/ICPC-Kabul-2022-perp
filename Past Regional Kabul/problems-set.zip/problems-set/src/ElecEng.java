import java.util.*;

public class ElecEng {
	static int maxindex(int[] dist, int n) {
		int mi = 0;
		for (int i = 0; i < n; i++) {
			if (dist[i] > dist[mi])
				mi = i;
		}
		return mi;
	}

	static void findProvince(int n, int weights[][], int k) {
		int[] dist = new int[n];
		ArrayList<Integer> centers = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			dist[i] = Integer.MAX_VALUE;
		}
		int max = 0;
		for (int i = 0; i < k; i++) {
			centers.add(max);
			for (int j = 0; j < n; j++) {
				dist[j] = Math.min(dist[j], weights[max][j]);
			}
			max = maxindex(dist, n);
		}
		System.out.println(dist[max]);

		for (int i = 0; i < centers.size(); i++) {
			System.out.print((centers.get(i) + 1) + " ");
		}
		System.out.print("\n");
	}

	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		int testCase = Integer.parseInt(inp.nextLine());

		for (int test = 0; test < testCase; test++) {
			String TranzVillage[] = inp.nextLine().split(" ");
			int tranz = Integer.parseInt(TranzVillage[0]);
			int village = Integer.parseInt(TranzVillage[1]);
			int vill[][] = new int[village][village];
			for (int v = 0; v < village; v++) {
				String vLine[] = inp.nextLine().split(",");
				for (int i = 0; i < village; i++) {
					vill[v][i] = Integer.parseInt(vLine[i]);
				}
			}
			findProvince(village, vill, tranz);
		}

		inp.close();
	}
}
