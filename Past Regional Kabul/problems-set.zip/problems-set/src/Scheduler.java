import static java.lang.Integer.parseInt;
import static java.lang.String.join;
import static java.lang.System.out;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Scheduler {
	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				String[] conf = input.nextLine().split(" ");
				int execTime = parseInt(conf[0]);
				int taskCount = parseInt(conf[1]);

				List<String> tasks = new ArrayList<>();
				// keep the task remaining durations
				Map<String, Integer> remainings = new HashMap<>();
				while (taskCount-- > 0) {
					String[] taskInfo = input.nextLine().split(" ");
					remainings.put(taskInfo[0], parseInt(taskInfo[1]));
					tasks.add(taskInfo[0]);
				}

				List<String> completed = new ArrayList<>();

				// execute task in order they are submitted
				while (!tasks.isEmpty()) {
					String taskName = tasks.remove(0);
					int remaining = remainings.get(taskName) - execTime;

					if (remaining > 0) {
						tasks.add(taskName);
						remainings.put(taskName, remaining);
					} else {
						remainings.remove(taskName);
						completed.add(taskName);
					}
				}

				out.println(join(" ", completed));
			}
		}
	}
}
