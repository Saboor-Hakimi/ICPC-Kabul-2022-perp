import static java.lang.Integer.parseInt;
import static java.lang.System.out;

import java.util.Scanner;

public class Barrels {
	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				int volume = parseInt(input.nextLine());
				int liters = 0;

				// sum the liters per shift per cow
				String line = "";
				while (!(line = input.nextLine()).trim().isEmpty()) {
					for (String shift : line.split(" ")) {
						liters += parseInt(shift);
					}
				}

				// find the barrel count
				if (liters == 0) {
					out.println(0);
				} else {
					// we need one more if there is an overflow
					out.println(liters / volume + (liters % volume == 0 ? 0 : 1));
				}
			}
		}
	}
}
