import static java.lang.Integer.parseInt;
import static java.lang.Math.round;
import static java.lang.System.out;

import java.util.Scanner;

public class Bandwidth {
	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				int count = parseInt(input.nextLine());

				int downloadTotal = 0, uploadTotal = 0, lastMillis = 0;
				while (count-- > 0) {
					String[] parts = input.nextLine().split(" ");

					int curMillis = parseInt(parts[0]);
					int download = parseInt(parts[1]);
					int upload = parseInt(parts[2]);

					int curSec = curMillis / 1000;
					int lastSec = lastMillis / 1000;

					// second is changed
					if (curSec > lastSec) {
						// print humanized (even for missing seconds)
						while (lastSec++ < curSec) {
							out.println(humanizeBytes(downloadTotal) + "/" + humanizeBytes(uploadTotal));

							downloadTotal = 0;
							uploadTotal = 0;
						}

						// remember the last record ms
						lastMillis = curMillis;
					}

					downloadTotal += download;
					uploadTotal += upload;
				}

				if (downloadTotal != 0) {
					out.println(humanizeBytes(downloadTotal) + "/" + humanizeBytes(uploadTotal));
				}

				if (tsCount > 0) {
					// the test case result separator
					out.println("---");
				}
			}
		}
	}

	private static String humanizeBytes(double bytes) {
		for (String scale : new String[] { "B", "KB", "MB", "GB", "TB" }) {
			if (bytes < 1024) {
				return format(bytes, scale);
			}
			bytes /= 1024;
		}
		return format(bytes, "TB");
	}

	private static String format(double value, String scale) {
		value = (int) round(value * 100.0) / 100.0;
		if (value % 1 != 0) {
			return value + scale;
		} else {
			return (int) value + scale;
		}
	}
}
