import static java.lang.Integer.parseInt;
import static java.lang.System.out;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SecretMsg {
	public static void main(String[] args) {
		Map<String, String> kmap = new HashMap<>();
		kmap.put("1", "1");
		kmap.put("2", "2");
		kmap.put("3", "3");
		kmap.put("4", "4");
		kmap.put("5", "5");
		kmap.put("6", "6");
		kmap.put("7", "7");
		kmap.put("8", "8");
		kmap.put("9", "9");
		kmap.put("0", "0");
		kmap.put("00", " ");
		kmap.put("22", "a");
		kmap.put("222", "b");
		kmap.put("2222", "c");
		kmap.put("33", "d");
		kmap.put("333", "e");
		kmap.put("3333", "f");
		kmap.put("44", "g");
		kmap.put("444", "h");
		kmap.put("4444", "i");
		kmap.put("55", "j");
		kmap.put("555", "k");
		kmap.put("5555", "l");
		kmap.put("66", "m");
		kmap.put("666", "n");
		kmap.put("6666", "o");
		kmap.put("77", "p");
		kmap.put("777", "q");
		kmap.put("7777", "r");
		kmap.put("77777", "s");
		kmap.put("88", "t");
		kmap.put("888", "u");
		kmap.put("8888", "v");
		kmap.put("99", "w");
		kmap.put("999", "x");
		kmap.put("9999", "y");
		kmap.put("99999", "z");

		try (Scanner input = new Scanner(System.in)) {
			int tsCount = parseInt(input.nextLine());

			while (tsCount-- > 0) {
				String[] words = input.nextLine().split(" ");
				// decode
				for (int i = 0; i < words.length; i++) {
					words[i] = kmap.get(words[i]);
				}
				out.println(String.join("", words));
			}
		}
	}
}
